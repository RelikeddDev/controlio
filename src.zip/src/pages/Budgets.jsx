const Budgets = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Presupuestos</h1>
      <p>Gestiona tus presupuestos mensuales.</p>
    </div>
  );
};

export default Budgets;
