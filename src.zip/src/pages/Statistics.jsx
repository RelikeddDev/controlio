const Statistics = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Estadísticas</h1>
      <p>Visualiza gráficos y análisis de tus finanzas.</p>
    </div>
  );
};

export default Statistics;
