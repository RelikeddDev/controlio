const NotFound = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">404 - Página no encontrada</h1>
      <p>La ruta que buscaste no existe.</p>
    </div>
  );
};

export default NotFound;
