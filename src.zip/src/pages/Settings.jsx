const Settings = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Configuración</h1>
      <p>Ajusta tus preferencias de la aplicación.</p>
    </div>
  );
};

export default Settings;
