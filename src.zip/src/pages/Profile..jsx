const Profile = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Perfil</h1>
      <p>Información de tu cuenta.</p>
    </div>
  );
};

export default Profile;
