import dayjs from 'dayjs';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';

dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);

/**
 * Calcula la próxima fecha de pago y el monto basado en el ciclo de la tarjeta,
 * considerando compras normales, diferidas (MSI) y recurrentes.
 * @param {Object} card - Información de la tarjeta
 * @param {Array} transactions - Transacciones de la tarjeta
 * @param {dayjs} [baseDate=dayjs()] - Fecha base para el cálculo (por defecto hoy)
 * @returns {Object} - Información del próximo pago
 */
export const calculateNextPayment = (card, transactions = [], baseDate = dayjs()) => {
  const today = baseDate;
  const { cutoffDay, paymentDay } = card;

  // Obtener el período de facturación para la fecha base
  const currentBillingPeriod = getCurrentBillingPeriod(today, cutoffDay);

  // Calcular la fecha de pago para este período
  const paymentDate = calculatePaymentDate(currentBillingPeriod.end, paymentDay);

  // Filtrar transacciones normales del período actual (no diferidas ni recurrentes)
  const periodTransactions = filterTransactionsByPeriod(
    transactions.filter(tx => !tx.deferred && !tx.recurring),
    currentBillingPeriod.start,
    currentBillingPeriod.end
  );

  // Sumar solo gastos (type === "expense") de transacciones normales
  let totalAmount = periodTransactions.reduce((sum, transaction) => {
    return transaction.type === "expense" ? sum + Math.abs(transaction.amount) : sum;
  }, 0);

  // --- MSI / Diferidos ---
  // Para cada transacción diferida, suma el pago mensual si corresponde a este ciclo de pago
  const deferredTransactions = transactions.filter(tx => tx.deferred);

  // Aquí guardamos los pagos MSI que caen en este periodo
  const msiPaymentsThisPeriod = [];

  deferredTransactions.forEach(tx => {
    if (!tx.firstPaymentDate || !tx.installments) return;
    const firstPayment = dayjs(tx.firstPaymentDate);
    const monthlyAmount = Math.abs(tx.amount) / tx.installments;
    for (let i = 0; i < tx.installments; i++) {
      const paymentDue = firstPayment.add(i, 'month');
      // Si el pago cae en el mismo mes y año que la fecha de pago de este ciclo, lo sumamos
      if (
        paymentDue.year() === paymentDate.year() &&
        paymentDue.month() === paymentDate.month()
      ) {
        totalAmount += monthlyAmount;
        // Agrega un objeto representando el pago MSI de este mes
        msiPaymentsThisPeriod.push({
          ...tx,
          msiMonth: i + 1,
          msiTotal: tx.installments,
          paymentDue: paymentDue.format('YYYY-MM-DD'),
          amount: monthlyAmount,
          isMSI: true
        });
      }
    }
  });

  // --- Gastos Recurrentes ---
  // Para cada transacción recurrente, verificar si debe incluirse en este período
  const recurringTransactions = transactions.filter(tx => tx.recurring);

  recurringTransactions.forEach(tx => {
    if (shouldIncludeRecurringTransaction(tx, currentBillingPeriod, paymentDate)) {
      totalAmount += Math.abs(tx.amount);
    }
  });

  // Contar todas las transacciones que afectan este período
  const activeRecurringCount = recurringTransactions.filter(tx =>
    shouldIncludeRecurringTransaction(tx, currentBillingPeriod, paymentDate)
  ).length;

  return {
    paymentDate: paymentDate.format('YYYY-MM-DD'),
    paymentDateFormatted: paymentDate.format('DD/MM/YYYY'),
    totalAmount: Number(totalAmount.toFixed(2)),
    billingPeriod: {
      start: currentBillingPeriod.start.format('DD/MM/YYYY'),
      end: currentBillingPeriod.end.format('DD/MM/YYYY')
    },
    transactionsCount: periodTransactions.length + msiPaymentsThisPeriod.length + activeRecurringCount,
    daysUntilPayment: paymentDate.diff(dayjs(), 'day'), // OJO: aquí puedes dejarlo como baseDate.diff(dayjs(), 'day') si quieres que sea relativo al mes consultado
    periodTransactions,
    recurringTransactions: recurringTransactions.filter(tx =>
      shouldIncludeRecurringTransaction(tx, currentBillingPeriod, paymentDate)
    ),
    msiPaymentsThisPeriod // <--- ¡Aquí está el arreglo para el modal!
  };
};

/**
 * Determina si una transacción recurrente debe incluirse en el período de facturación actual
 * @param {Object} transaction - Transacción recurrente
 * @param {Object} billingPeriod - Período de facturación actual
 * @param {dayjs} paymentDate - Fecha de pago del período
 * @returns {boolean} - Si debe incluirse o no
 */
const shouldIncludeRecurringTransaction = (transaction, billingPeriod, paymentDate) => {
  if (!transaction.recurring || !transaction.recurringStartDate) return false;

  const startDate = dayjs(transaction.recurringStartDate);
  const endDate = transaction.recurringEndDate ? dayjs(transaction.recurringEndDate) : null;

  // Verificar si la suscripción está activa durante este período
  const isActiveAtPeriodStart = startDate.isBefore(billingPeriod.end.add(1, 'day'));
  const isActiveAtPeriodEnd = !endDate || endDate.isAfter(billingPeriod.start);

  if (!isActiveAtPeriodStart || !isActiveAtPeriodEnd) return false;

  // Para gastos mensuales, verificar si corresponde a este mes de pago
  if (transaction.recurringInterval === 'monthly') {
    // Si la fecha de inicio es antes del final del período, incluir el cargo
    return startDate.isBefore(billingPeriod.end.add(1, 'day'));
  }

  return false;
};

/**
 * Obtiene el período de facturación actual basado en la fecha de corte
 * @param {dayjs} currentDate - Fecha base
 * @param {number} cutoffDay - Día de corte (1-31)
 * @returns {Object} - Período de facturación
 */
export const getCurrentBillingPeriod = (currentDate, cutoffDay) => {
  const currentDay = currentDate.date();

  let periodStart, periodEnd;

  if (currentDay <= cutoffDay) {
    // Estamos en el período actual (antes del corte)
    periodStart = currentDate.subtract(1, 'month').date(cutoffDay + 1);
    periodEnd = currentDate.date(cutoffDay);
  } else {
    // Estamos después del corte, nuevo período
    periodStart = currentDate.date(cutoffDay + 1);
    periodEnd = currentDate.add(1, 'month').date(cutoffDay);
  }

  return { start: periodStart, end: periodEnd };
};

/**
 * Calcula la fecha de pago basada en el final del período y el día de pago
 * @param {dayjs} periodEnd - Final del período de facturación
 * @param {number} paymentDay - Día de pago del mes
 * @returns {dayjs} - Fecha de pago
 */
export const calculatePaymentDate = (periodEnd, paymentDay) => {
  // El pago es en el mismo mes que termina el periodo, no un mes después
  // Si el día de pago es después del día de corte, es en el mismo mes
  // Si el día de pago es antes o igual al día de corte, es el mes siguiente
  const periodEndDay = periodEnd.date();
  if (paymentDay > periodEndDay) {
    // Pago en el mismo mes
    return periodEnd.date(paymentDay);
  } else {
    // Pago el mes siguiente
    return periodEnd.add(1, 'month').date(paymentDay);
  }
};

/**
 * Filtra transacciones por período de facturación
 * @param {Array} transactions - Todas las transacciones
 * @param {dayjs} periodStart - Inicio del período
 * @param {dayjs} periodEnd - Final del período
 * @returns {Array} - Transacciones filtradas
 */
export const filterTransactionsByPeriod = (transactions, periodStart, periodEnd) => {
  return transactions.filter(transaction => {
    const transactionDate = dayjs(transaction.date);
    return transactionDate.isSameOrAfter(periodStart, 'day') &&
      transactionDate.isSameOrBefore(periodEnd, 'day');
  });
};

/**
 * Obtiene todos los próximos pagos para múltiples tarjetas
 * @param {Array} cards - Array de tarjetas
 * @param {Array} transactions - Todas las transacciones
 * @returns {Array} - Próximos pagos ordenados por fecha
 */
export const getAllUpcomingPayments = (cards, transactions) => {
  const creditCards = cards.filter(card => card.type === 'credit');

  const payments = creditCards.map(card => {
    const cardTransactions = transactions.filter(t => t.cardId === card.id);
    const paymentInfo = calculateNextPayment(card, cardTransactions);

    return {
      cardId: card.id,
      cardName: card.name,
      cardType: card.type,
      bank: card.bank,
      lastFourDigits: card.lastFourDigits,
      color: card.color,
      ...paymentInfo
    };
  });

  // Ordenar por fecha de pago más cercana
  return payments.sort((a, b) => dayjs(a.paymentDate).diff(dayjs(b.paymentDate)));
};

/**
 * Obtiene todas las transacciones recurrentes activas para una tarjeta
 * @param {Array} transactions - Todas las transacciones
 * @param {string} cardId - ID de la tarjeta
 * @returns {Array} - Transacciones recurrentes activas
 */
export const getActiveRecurringTransactions = (transactions, cardId) => {
  const today = dayjs();

  return transactions.filter(tx =>
    tx.recurring &&
    tx.cardId === cardId &&
    dayjs(tx.recurringStartDate).isBefore(today.add(1, 'day')) &&
    (!tx.recurringEndDate || dayjs(tx.recurringEndDate).isAfter(today))
  );
};