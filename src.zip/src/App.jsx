import { ConfigProvider, theme } from 'antd';
import { useSelector } from 'react-redux';
import AppRouter from './router';

const App = () => {
  const darkMode = useSelector((state) => state.theme.darkMode);

  return (
    <ConfigProvider
      theme={{
        algorithm: darkMode ? theme.darkAlgorithm : theme.defaultAlgorithm,
      }}
    >
      <AppRouter />
    </ConfigProvider>
  );
};

export default App;
