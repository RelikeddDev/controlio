import React, { useState } from 'react';
import { Layout, theme } from 'antd';
import HeaderBar from './components/HeaderBar.jsx';
import SiderMenu from './components/SiderMenu.jsx';
import AppFooter from './components/AppFooter.jsx';
import { Outlet } from 'react-router-dom';

const { Content } = Layout;

const AppLayout = () => {
  const {
    token: { colorBgContainer, borderRadiusLG, colorBgLayout },
  } = theme.useToken();

  const [collapsed, setCollapsed] = useState(false);
  const siderWidth = collapsed ? 80 : 220;

  return (
    <Layout style={{ minHeight: '100vh', background: colorBgLayout }}>
      <SiderMenu collapsed={collapsed} setCollapsed={setCollapsed} />

      <Layout style={{ marginLeft: siderWidth }}>
        <HeaderBar />

        <Content
          style={{
            margin: '24px 16px 0',
            padding: 24,
            overflowY: 'auto',
            // height: 'calc(100vh - 64px - 64px)', // Altura total - Header - Footer
            background: colorBgContainer,
            borderRadius: borderRadiusLG,
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
          }}
        >
          <Outlet />
        </Content>

        <AppFooter />
      </Layout>
    </Layout>
  );
};

export default AppLayout;
