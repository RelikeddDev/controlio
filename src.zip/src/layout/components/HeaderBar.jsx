import React from 'react';
import { Layout, Typography, Switch, Space, Breadcrumb } from 'antd';
import { useDispatch, useSelector } from 'react-redux';
import { setDarkMode } from '../../store/themeSlice';
import { BulbFilled, BulbOutlined } from '@ant-design/icons';
import { useLocation, Link } from 'react-router-dom';

const { Header } = Layout;
const { Title } = Typography;

const HeaderBar = () => {
  const dispatch = useDispatch();
  const darkMode = useSelector((state) => state.theme.darkMode);
  const location = useLocation();

  const toggleTheme = () => {
    dispatch(setDarkMode(!darkMode));
  };

  // Mapa para nombres amigables de segmentos de ruta
  const segmentNames = {
    '': 'Dashboard',
    transactions: 'Transacciones',
    categories: 'Categorías',
    budgets: 'Presupuestos',
    statistics: 'Estadísticas',
    settings: 'Configuración',
    cards: 'Tarjetas',
    // Puedes agregar más según rutas nuevas
  };

  // Dividir ruta en segmentos y construir breadcrumb
  const pathSegments = location.pathname.split('/').filter(Boolean); // quita elementos vacíos

  // Armar arreglo para breadcrumb: 
  // ejemplo: '/transactions/123' => [{path: '/transactions', name: 'Transacciones'}, {path:'/transactions/123', name:'123'}]
  const breadcrumbItems = pathSegments.map((segment, index) => {
    // Ruta acumulada para el segmento actual
    const url = '/' + pathSegments.slice(0, index + 1).join('/');

    // Obtener nombre amigable o fallback al segmento crudo
    const name = segmentNames[segment] || segment;

    return { url, name };
  });

  // Si ruta es / (vacía), poner Dashboard en breadcrumb
  if (breadcrumbItems.length === 0) {
    breadcrumbItems.push({ url: '/', name: segmentNames[''] });
  }

  return (
    <Header
      style={{
        padding: '0 24px',
        background: 'transparent',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        height: 64,
      }}
    >
      <div>
        <Breadcrumb
          style={{ color: darkMode ? '#fff' : '#000', fontSize: 18 }}
          items={breadcrumbItems.map(({ url, name }) => ({
            key: url,
            title: <Link to={url} style={{ color: darkMode ? '#fff' : '#000' }}>{name}</Link>,
          }))}
        />
      </div>

      <Space>
        {darkMode ? <BulbFilled style={{ color: '#fadb14' }} /> : <BulbOutlined />}
        <Switch checked={darkMode} onChange={toggleTheme} />
      </Space>
    </Header>
  );
};

export default HeaderBar;
