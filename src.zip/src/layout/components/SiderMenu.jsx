import React from 'react';
import { Layout, Menu } from 'antd';
import {
  HomeOutlined,
  DollarOutlined,
  ShoppingCartOutlined,
  PieChartOutlined,
  SettingOutlined,
  CreditCardOutlined ,
} from '@ant-design/icons';
import { useNavigate, useLocation } from 'react-router-dom';

const { Sider } = Layout;

const SiderMenu = ({ collapsed, setCollapsed }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    { key: '/', icon: <HomeOutlined />, label: 'Dashboard' },
    { key: '/transactions', icon: <DollarOutlined />, label: 'Transacciones' },
    { key: '/categories', icon: <ShoppingCartOutlined />, label: 'Categorías' },
    { key: '/budgets', icon: <PieChartOutlined />, label: 'Presupuestos' },
    { key: '/statistics', icon: <PieChartOutlined />, label: 'Estadísticas' },
    { key: '/cards', icon: <CreditCardOutlined />, label: 'Tarjetas' },
    { key: '/settings', icon: <SettingOutlined />, label: 'Configuración' },
  ];

  const handleClick = ({ key }) => {
    if (location.pathname !== key) {
      navigate(key);
    }
  };

  const selectedKey = `/${location.pathname.split('/')[1] || ''}`;

  return (
    <Sider
      collapsible
      collapsed={collapsed}
      onCollapse={setCollapsed}
      width={220}
      style={{
        height: '100vh',
        position: 'fixed',
        left: 0,
        top: 0,
        zIndex: 100,
        backgroundColor: '#001529',
      }}
    >
      <Menu
        theme="dark"
        mode="inline"
        selectedKeys={[selectedKey]}
        onClick={handleClick}
        items={menuItems}
      />
    </Sider>
  );
};

export default SiderMenu;
